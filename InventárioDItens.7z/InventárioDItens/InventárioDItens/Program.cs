﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
public class Itens
{
    public string name;
    public Itens next = null;

    public Itens(string name)
    {
        this.name = name;
    }
}


namespace InventárioDItens


{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Qual item você quer usar?");
            string a = Console.ReadLine();
            Itens Itens1 = new Itens("pot");
            Itens Itens2 = new Itens("cachorro");
            Itens Itens3 = new Itens("furacao2000");
            Itens Itens4 = new Itens("elmo");
            Itens Itens5 = new Itens("Cajado");
            Itens Itens6 = new Itens("capa");
            Itens Itens7 = new Itens("gladio");
            Itens Itens8 = new Itens("kugarisama");
            Itens Itens9 = new Itens("sabre");
            Itens Itens10 = new Itens("nutella");

            Itens1.next = Itens2;
            Itens2.next = Itens3;
            Itens3.next = Itens4;
            Itens4.next = Itens5;
            Itens5.next = Itens6;
            Itens6.next = Itens7;
            Itens7.next = Itens8;
            Itens8.next = Itens9;
            Itens9.next = Itens10;


            
            Itens currentElement = Itens1;
            int pos = 1;
            while (currentElement != null  )
            {
              
                if (a == currentElement.name)
                {
                    Console.WriteLine("achamos o item. é o :" + a + ". e esta na posicao " + pos);
                    return;
                }
                else {
                    Console.WriteLine("voce nao tem o item");
                  //  return
                }
                currentElement = currentElement.next;
                pos++;

            }
        }

        
    }
}
